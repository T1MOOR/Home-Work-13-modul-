


// Создайте кортеж для двух человек с одинаковыми типами данных и параметрами.
//При том одни значения доставайте по индексу, а другие — по параметру.
let person1: (Int, String, String) = (age: 36, name: "Timur", surname: "Garipov")
let person2 = (age: 35, name: "Dima", surname: "Kiselev")

person1.0
person2.name



//T2 Создайте массив «дни в месяцах» (12 элементов содержащих количество дней в соответствующем месяце).

// выведите количество дней в каждом месяце
let dayMonth = [31, 28, 31, 30, 31, 30, 31, 30, 31, 31, 30, 31]
for item in dayMonth {
    print(item)
}
print("")

// используйте еще один массив с именами месяцев чтобы вывести название месяца + количество дней
let january = "January"
let february = "February"
let march = "March"
let april = "April"
let may = "May"
let june = "June"
let july = "July"
let august = "August"
let september = "September"
let october = "October"
let november = "November"
let december = "December"


let nameOfMonth = [january, february, march, april, may, june, july, august, september ,october, november, december]

for c in 0...11 {
    print("\(dayMonth[c]) days in \(nameOfMonth[c])")
}
print("")


//сделайте тоже самое, но используя массив кортежей с параметрами (имя месяца, количество дней)

let daysOnEachMonth: [String: Int] = ["January": 31, "February": 28, "March": 31, "April": 30, "May": 31, "June": 30, "July": 31, "August": 30, "September": 31, "October": 31, "November": 30, "December": 31]


for (subject, days) in daysOnEachMonth {
    print("\(subject) has \(days) days")
}
print("")

for i in (0 ..< nameOfMonth.count).reversed() {
    print ("Month \(nameOfMonth[i]) has \(dayMonth[i]) days")
}

print("")


//для произвольно выбранной даты (месяц и день) посчитайте количество дней до конца года
let (month, day) = (07, 15)
let monthIndex = month - 1
var sumDays = day

for count in dayMonth[0..<monthIndex]{
   sumDays += count
}
print(365 - sumDays)
print("")




// 3. Создайте словарь, как журнал студентов, где имя и фамилия студента это ключ, а оценка за экзамен — значение.

var studentList = ["Ivan Petrov": 5, "Fedor Ivanov": 2, "Dmirtii Volkov": 3, "Mariya Pestunova": 5, "Daria Gracheva": 4]



//Повысьте студенту оценку за экзамен

studentList["Dmirtii Volkov"] = 4

studentList.updateValue(3, forKey: "Fedor Ivanov")

print(studentList)
print("")


//Если оценка положительная (4 или 5) или удовлетворительная (3), то выведите сообщение с поздравлением, отрицательная (1, 2) - отправьте на пересдачу

for (student, exam) in studentList {
    if exam <= 2 {
        print("\(student): Вам нужно пересдать экзамен")
    }else {
        print("\(student): Поздравляем, вы сдали экзамен!")
    }
}
print("")


//Добавьте еще несколько студентов — это ваши новые одногруппники!

studentList["Maria Chumel"] = 5
studentList ["Egor Khlistov"] = 4
studentList ["Nikolay Seregin"] = 5
studentList ["Olga Petrova"] = 4
print (studentList)
print("")



//Удалите одного студента — он отчислен
studentList["Fedor Ivanov"] = nil

studentList.removeValue(forKey: "Dmirtii Volkov")
print (studentList)
print("")



//Посчитайте средний балл всей группы по итогам экзамена.
var count = studentList.count
var averageScores:Double = Double()
for score in studentList.values {
    averageScores += Double(score) / Double(count)
}
print(Int(averageScores))
